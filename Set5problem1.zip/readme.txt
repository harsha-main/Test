Please compile the file TameThrones1.java and execute it.
This program runs until the input "exit" is entered in the terminal.
